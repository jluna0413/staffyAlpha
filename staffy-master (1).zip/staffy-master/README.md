﻿Ruby 2.4
Rails 5.1.1
Postgresql 9.6

cd staffy
rails s in terminal to start server
ctrl + c to stop server
