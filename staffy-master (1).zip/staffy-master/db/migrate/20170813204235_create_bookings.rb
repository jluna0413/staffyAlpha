class CreateBookings < ActiveRecord::Migration[5.1]
  def change
    create_table :bookings do |t|
      t.boolean :isfullfilled
      t.references :job, foreign_key: true

      t.timestamps
    end
  end
end
