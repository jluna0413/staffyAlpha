class Booking < ApplicationRecord
  belongs_to :job
end
