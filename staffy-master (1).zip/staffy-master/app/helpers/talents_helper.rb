module TalentsHelper
end
