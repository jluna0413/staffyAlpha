require 'test_helper'

class TalentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
