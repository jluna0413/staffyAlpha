require "application_system_test_case"

class JobsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit jobs_url
  #
  #   assert_selector "h1", text: "Job"
  # end
end
