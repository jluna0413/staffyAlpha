require "application_system_test_case"

class TalentsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit talents_url
  #
  #   assert_selector "h1", text: "Talent"
  # end
end
